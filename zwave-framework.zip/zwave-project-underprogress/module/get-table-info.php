<?php

function showtables(){
	include 'table-schema.php';
}
?>