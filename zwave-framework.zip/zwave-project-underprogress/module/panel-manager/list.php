<?php

#filename that will be automatically made inside .panel folder

$files=[];

$files[]='.htaccess';
$files[]='changecode.php';
$files[]='changeurl.php';
$files[]='index.php';
$files[]='panel.php';

# filestorage db
$FILESOURCE='panelmanager.class';

?>
