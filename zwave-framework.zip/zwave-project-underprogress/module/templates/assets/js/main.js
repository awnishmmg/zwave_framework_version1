// This is js file related to main template js
