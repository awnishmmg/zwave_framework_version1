<?php

include 'module/templates/get_settings.php';

?>

<!-- This is Footer Template to be Loaded Automatically -->



<!-- This is Footer Template to be Loaded Automatically -->

</div>
</main>
<footer>
	<div id="footer">
		<center>&copy; to awisoft.net @2020</center>
	</footer>
</div>
	<?php $scripts(); ?>
</body>
</html>