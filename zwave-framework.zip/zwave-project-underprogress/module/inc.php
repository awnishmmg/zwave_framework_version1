<?php

#database Connection Init file 

@define('DB_VAR',include 'db_init/__init__.php');

#connection object 

#define('EXTEND_QUERY',include 'query-builder.php');


?>