<?php
#Host name for the Connecting with the mysqlserver$db["driver_name"]="MYSQL"
$db["sqli"]="true"; #use of sqli instead of sql is recommended
$db["host"]="localhost"; #use of host-name
$db["user"]="root"; #userName for Connection with Database Engine
$db["pass"]=""; #password for the Connection with the Database
$db["db"]="zwavedb"; #db name is Important if database is not avaliable the we need to create Database;




?>