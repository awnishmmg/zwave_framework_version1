<?php

function gotopage($pagename)
{
	header("location:$pagename");
}


?>