<?php
define('y',true);
define('n',false);
?>