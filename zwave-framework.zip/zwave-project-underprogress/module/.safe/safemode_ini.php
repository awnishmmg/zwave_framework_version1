<?php
include 'define.php';

/*
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

================================| License Agreement |====================================

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#########################################################################################
 ****************************************************************************************
 Author : Awnish Kumar *
 					   * This is simple but power ful framework for crud and other 
 				&	   * Important stuffs like Authenctication and-session-login it 
 					   * also support key log out Mechanism this project is 
 					   * underconstruction and will be available github repository. 
 	 Shivani Dwivedi   * @safe mode Environment during developement. 
 Credit :Rohit Kumar   *  ***************************************************************
************************

#########################################################################################
*****************************************************************************************
@Copywrite to © Awnish Kumar
*****************************************************************************************
@contact | +91-7081030240
@Email   | awnishmmg.a41@gamil.com
*****************************************************************************************

############################    Information about this Page  ############################

Any one who is using this project will be working under a environment called @safe mode which is responsible for mainting the level of security over sessions but if develope
wants he can disable this by setting below @param.

*****************************************************************************************
$debugmode=y for Yes/True 
$debugmode=n for No/false

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/



$debugmode=y; 									#| Enable | Disable @safe Mode |





########################################################################################



?>