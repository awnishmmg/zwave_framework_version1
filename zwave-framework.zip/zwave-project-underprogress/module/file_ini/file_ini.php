<?php

##########################################################################

$landingpage='login'; #this is page where user will be re-directed always |This is Not same as your homepage

$allowpage['loginpage']=$landingpage; #set Your User Login Page
###########################################################################

#set all the pages you want End User to get as a defualt HTTP Request Response

$allowpage['homepage']='welcome'; #set Your Home Page
$allowpage['creating-database']='commit-database'; #set Your Home Page

#----------------------------------------------------------------------------------






?>