<?php

	die("<center><h3>Access Denied No such file or Address exist</h3></center>");
	exit;
?>