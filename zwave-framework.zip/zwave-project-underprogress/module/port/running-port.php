<?php 
$portno=70
 ?>