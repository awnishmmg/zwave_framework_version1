<?php

$dirlist=scandir("module/");

?>