<?php
    echo "This page is fixed for login page ";
?>