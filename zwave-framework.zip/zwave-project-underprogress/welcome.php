<?php

echo "This page is Landing page just like homepage and can also be used for register page"

#Comment or Remove this line we donot require
?>
